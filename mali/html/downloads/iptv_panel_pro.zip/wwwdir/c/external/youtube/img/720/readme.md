This directory contains images specific for resolution 1280*720
