This directory contains images specific for resolution 1920*1080
